# Changelog
### v1.0.2 - 14-07-2021
-Playlists and playlist sounds can not be dragged into the mixer to populare the soundboard or a channel
-Forgot to fix capitalization issues for the soundboard config, which prevented it from opening
-Soundscape name edits resulted in an error

### v1.0.1 - 14-07-2021
Fixed some capitalization issues, which prevented dialogs from opening

### v1.0.0 - 14-07-2021
Initial release<br>