# Changelog Soundscape Module

### v0.4.0 - 03-06-2021
Initial public beta release