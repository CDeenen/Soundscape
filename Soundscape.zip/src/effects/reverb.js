export class Reverb {
    constructor(channel) {
      
    }


}
